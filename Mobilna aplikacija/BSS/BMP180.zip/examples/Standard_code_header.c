

/******************************************************************************
<filename>
<Title>
<name @ SparkFun Electronics>
<original creation date>
<github repository address>

<multiline verbose description of file functionality>

Resources:
<additional library requirements>

Development environment specifics:
<arduino/development environment version>
<hardware version>
<etc>

This code is beerware; if you see me (or any other SparkFun employee) at the
local, and you've found our code helpful, please buy us a round!

Distributed as-is; no warranty is given.
******************************************************************************/